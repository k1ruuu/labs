﻿#include <SFML/Graphics.hpp>
#include <iostream>
#include "Game.hpp"

using namespace sf;

int main()
{
	ss::Game game;
	game.Run();

	return 0;
}