#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;
using namespace sf;

namespace ss {

	const int H = 12;
	const int W = 40;


	class Game {
	public:
		void Run();
	};


	class player {
	public:
		float x, y;
		FloatRect rect;
		bool onGround;
		Sprite sprite;
		float currentFrame;

		player(Texture& image);

		void update(float time);
		void Collision(int dir);
	};
}